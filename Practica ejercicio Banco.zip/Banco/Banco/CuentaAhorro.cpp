#include "StdAfx.h"
#include "CuentaAhorro.h"
#include "Cuenta.h"


CuentaAhorro::CuentaAhorro()
{
}
void CuentaAhorro::Set_CuotaManten(double cantidad)
{
	cuotaMantenimiento=cantidad;
}
double CuentaAhorro::Get_CuotaManten()
{
	return cuotaMantenimiento;
}
void CuentaAhorro::reintegro(double cantidad)
{
	saldo=saldo-cantidad-15;
}

#pragma once
class Cuadrado   //quitamos el REF-----
{
private:
	int lado,area;

public:
	Cuadrado(void);
	int Get_lado();
	int Get_area();
	void Set_lado(int L);
	void Set_area(int a);
	int Calcular();
};


#pragma once
#include "Cuadrado.h" //!!!!!!!!! IMPORTANTE !!!!!!!!!
#include <iostream>  //agregar
#include <string>    //agragar
#include <msclr\marshal_cppstd.h>//agregar

namespace AreACuadradO {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;                //----AGREGAR---- 
	using namespace msclr;               //----AGREGAR-----

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::TextBox^  txtLado;
	private: System::Windows::Forms::TextBox^  txtArea;
	private: System::Windows::Forms::Button^  btnCalcular;
	private: System::Windows::Forms::Label^  label2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtLado = (gcnew System::Windows::Forms::TextBox());
			this->txtArea = (gcnew System::Windows::Forms::TextBox());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(97, 21);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(35, 17);
			this->label1->TabIndex = 0;
			this->label1->Text = L"lado";
			// 
			// txtLado
			// 
			this->txtLado->Location = System::Drawing::Point(148, 21);
			this->txtLado->Name = L"txtLado";
			this->txtLado->Size = System::Drawing::Size(100, 22);
			this->txtLado->TabIndex = 1;
			// 
			// txtArea
			// 
			this->txtArea->Location = System::Drawing::Point(148, 204);
			this->txtArea->Name = L"txtArea";
			this->txtArea->Size = System::Drawing::Size(100, 22);
			this->txtArea->TabIndex = 2;
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(159, 117);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(75, 23);
			this->btnCalcular->TabIndex = 3;
			this->btnCalcular->Text = L"calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(97, 204);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(37, 17);
			this->label2->TabIndex = 4;
			this->label2->Text = L"area";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(282, 253);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->txtArea);
			this->Controls->Add(this->txtLado);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 Cuadrado cuadradochikito;                                           // este (cuadradochikito) es el objeto de la clase cuadrado --osea hay que crearlo para la tarea como un paso a seguir
				 cuadradochikito.Set_lado(System::Convert::ToInt32(txtLado->Text));  //metodo de la clase (.set_lado) objeto (cuadradochikito)
				 int areafin;                                                        //variable para que se le aisigne el objeto de la clase
				 areafin=cuadradochikito.Calcular();                                 //se asigna el objeto de la clase a (areafin)
				 txtArea->Text=System::Convert::ToString(areafin);                   //se muestra en el otro textbox
			 }
};
}


#pragma once
#include <iostream>
#include<string>

using namespace std;
using namespace System::Windows::Forms;

class ENTEROS
{
public:
	int enteros;
	ENTEROS(void){}

	void Leer(TextBox^ ent)
	{
		enteros=System::Convert::ToInt32(ent->Text);
	}

	void Mostrar(TextBox^ ent)
	{
		ent->Text=System::Convert::ToString(enteros);
	}

	ENTEROS Sumar_digitos()
	{
		ENTEROS aux;
		int digitos;
		aux.enteros=enteros;
		enteros=0;
		while(aux.enteros>0)
		{
			digitos=aux.enteros%10;
			aux.enteros=aux.enteros/10;
			enteros=digitos+enteros;
		}
		aux.enteros=enteros;
		return aux;
	}
};


#pragma once
class formula
{
private:
	float a,b,c,runo,rdos;
public:
	formula(void);
	float get_a();
	float get_b();
	float get_c();
	float get_runo();
	float get_rdos();

	void set_a(float A);
	void set_b(float B);
	void set_c(float C);
	void set_runo(float RU);
	void set_rdos(float RD);

	float calcular(); float calculardos();
};


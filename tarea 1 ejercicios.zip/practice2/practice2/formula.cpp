#include "StdAfx.h"
#include "formula.h"
#include <stdio.h>
#include <math.h>


formula::formula(void)
{
}

float formula::get_a(){return a;}
float formula::get_b(){return b;}
float formula::get_c(){return c;}

void formula::set_a(float A){a=A;}
void formula::set_b(float B){b=B;}
void formula::set_c(float C){c=C;}

float formula::calcular()
{runo=((-b+sqrt((b*b)-(4*a*c)))/(2*a));return runo;}

float formula::calculardos()
{rdos=((-b-sqrt((b*b)-(4*a*c)))/(2*a));return rdos;}


#pragma once
#include "formula.h" //!!!!!!!!! IMPORTANTE !!!!!!!!!
#include <iostream>  //agregar
#include <string>    //agragar
#include <msclr\marshal_cppstd.h>//agregar
#include <math.h>

namespace practice2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;                //----AGREGAR---- 
	using namespace msclr;               //----AGREGAR-----

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  txta;
	private: System::Windows::Forms::TextBox^  txtc;
	protected: 


	private: System::Windows::Forms::TextBox^  txtb;

	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtrdos;

	private: System::Windows::Forms::TextBox^  txtruno;

	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txta = (gcnew System::Windows::Forms::TextBox());
			this->txtc = (gcnew System::Windows::Forms::TextBox());
			this->txtb = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtrdos = (gcnew System::Windows::Forms::TextBox());
			this->txtruno = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(442, 27);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(149, 17);
			this->label1->TabIndex = 0;
			this->label1->Text = L"(-b+-sqrt(b^2-4ac))/2a";
			// 
			// txta
			// 
			this->txta->Location = System::Drawing::Point(140, 27);
			this->txta->Name = L"txta";
			this->txta->Size = System::Drawing::Size(100, 22);
			this->txta->TabIndex = 1;
			// 
			// txtc
			// 
			this->txtc->Location = System::Drawing::Point(140, 147);
			this->txtc->Name = L"txtc";
			this->txtc->Size = System::Drawing::Size(100, 22);
			this->txtc->TabIndex = 2;
			// 
			// txtb
			// 
			this->txtb->Location = System::Drawing::Point(140, 84);
			this->txtb->Name = L"txtb";
			this->txtb->Size = System::Drawing::Size(100, 22);
			this->txtb->TabIndex = 3;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(32, 30);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(89, 17);
			this->label2->TabIndex = 4;
			this->label2->Text = L"introduce \"a\"";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(32, 150);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(88, 17);
			this->label3->TabIndex = 5;
			this->label3->Text = L"introduce \"c\"";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(32, 89);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(89, 17);
			this->label4->TabIndex = 6;
			this->label4->Text = L"introduce \"b\"";
			// 
			// txtrdos
			// 
			this->txtrdos->Location = System::Drawing::Point(303, 249);
			this->txtrdos->Name = L"txtrdos";
			this->txtrdos->Size = System::Drawing::Size(100, 22);
			this->txtrdos->TabIndex = 7;
			// 
			// txtruno
			// 
			this->txtruno->Location = System::Drawing::Point(140, 249);
			this->txtruno->Name = L"txtruno";
			this->txtruno->Size = System::Drawing::Size(100, 22);
			this->txtruno->TabIndex = 8;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(347, 118);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(123, 52);
			this->button1->TabIndex = 9;
			this->button1->Text = L"calcular";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(315, 298);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(83, 17);
			this->label5->TabIndex = 10;
			this->label5->Text = L"respuesta 2";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(152, 298);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(83, 17);
			this->label6->TabIndex = 11;
			this->label6->Text = L"respuesta 1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(620, 448);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->txtruno);
			this->Controls->Add(this->txtrdos);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->txtb);
			this->Controls->Add(this->txtc);
			this->Controls->Add(this->txta);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 formula ra;
				 ra.set_a(System::Convert::ToInt32(txta->Text));
				 ra.set_b(System::Convert::ToInt32(txtb->Text));
				 ra.set_c(System::Convert::ToInt32(txtc->Text));
				 float may;
				 may=ra.calcular();
				 txtruno->Text=System::Convert::ToString(may);
				 may=ra.calculardos();
				 txtrdos->Text=System::Convert::ToString(may);
			 }
};
}


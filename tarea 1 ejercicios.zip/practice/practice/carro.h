#pragma once
#include <iostream>
#include <string.h>
using namespace std;
class carro
{
private:
	int numerochasis;
	string color,marca;
public:
	carro(void);
	int get_numerochasis ();
	string get_color ();
	string get_marca ();
	void set_numerochasis(int nc);
	void set_color(int c);
	void set_marca(int m);
};
#include "StdAfx.h"
#include "carro.h"
#include <string.h>


carro::carro(void)
{
}
string carro::get_color()
{return color;}
string carro::get_marca()
{return marca;}
int carro::get_numerochasis()
{return numerochasis;}

void carro::set_color(int c)
{color=c;}
void carro::set_marca(int m)
{marca=m;}
void carro::set_numerochasis(int nc)
{numerochasis=nc;}
#pragma once
class COmplejo
{
private:
	double real,imag;
public:
	COmplejo();
	COmplejo(double r, double i);
	void Set_real(double r);
	void Set_imag(double i);
	double Get_real();
	double Get_imag();
	void suma (COmplejo a,COmplejo b);
};


#include "StdAfx.h"
#include "COmplejo.h"


COmplejo::COmplejo(void)
{
}

COmplejo::COmplejo(double r, double i)
{
	real=r;
	imag=i;
}

double COmplejo::Get_real()
{
	return real;
}

double COmplejo::Get_imag()
{
	return imag;
}


void COmplejo::Set_real(double r)
{
	real=r;
}

void COmplejo::Set_imag(double i)
{
	imag=i;
}

void COmplejo::suma(COmplejo a, COmplejo b)
{
	real=a.real+b.real;
    imag=a.imag+b.imag;
}
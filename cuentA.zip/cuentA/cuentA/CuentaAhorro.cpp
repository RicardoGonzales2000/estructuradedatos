#include "StdAfx.h"
#include "CuentaAhorro.h"
#include "Cuenta.h"


CuentaAhorro::CuentaAhorro(void)
{
}
void CuentaAhorro::Set_CuotaManten(double cantidad)
{
	cuotaManten=cantidad;
}
double CuentaAhorro::Get_CuotaManten()
{
	return cuotaManten;
}
void CuentaAhorro::reintegro(double cantidad)
{
	saldo=saldo-cantidad;

}

#pragma once
#include <iostream>
#include <string>
using namespace std;
class CuentaAhorro
{
private:
	double cuotaManten;
public:
	void CuentaAhorro(string nom, string cue, double sal, double tipo, double mant);
	void Set_CuotaManten(double cantidad);
	double Get_CuotaManten();
		void reintegro(double cantidad);
};

